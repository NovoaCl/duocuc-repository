
package com.mycompany.autoview;


public class Master {}

//----------------------------- CONTROLLER -----------------------------

public class MenuController {

    private Menu vista;

    public MenuController(Menu vista) {
        this.vista = vista;
        escucharEventos();
    }

    private void escucharEventos() {
        vista.btnGuardar.addActionListener(e -> guardar());
        vista.btnLimpiar.addActionListener(e -> limpiar());
        vista.btnCargar.addActionListener(e -> cargar());
        vista.btnSalir.addActionListener(e -> salir());
    }

    private void guardar() {
        String marca = vista.txtMarca.getText();
        String color = vista.txtColor.getText();

        Auto auto = new Auto(marca, color);

        try {
            AutoService as = new AutoService();
            as.registarAuto(auto);
            JOptionPane.showMessageDialog(vista, "Auto agregado con exito");
            limpiar();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Se produjo un error: " + e);
        }
    }

    public void limpiar() {
        vista.txtMarca.setText(null);
        vista.txtColor.setText(null);
    }

 public void cargar() {
    String[] columnas = {"Marca", "Color"};
    DefaultTableModel modelo = new DefaultTableModel(columnas, 0);
    AutoDAO as = new AutoDAO();

    try {
        List<Auto> listAutos = as.listar(); // ✅ nombre correcto del método

        for (Auto a : listAutos) {
            Object[] fila = {
                a.getMarca(),
                a.getColor()
            };
            modelo.addRow(fila);
        }

        vista.tblListar.setModel(modelo); // ✅ solo una vez

    } catch (Exception e) {
        e.printStackTrace(); // ✅ muestra el error real
        JOptionPane.showMessageDialog(null, "Error al cargar datos: " + e.getMessage());
    }
}

    public void salir() {
        vista.dispose();
    }
}

//----------------------------- DAO -----------------------------

public class AutoDAO {

    public void registro(Auto a) throws SQLException {
        String sql = "INSERT INTO auto (marca, color)"
                + "VALUES (?, ?)";
        try (Connection conn = ConexionDB.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, a.getMarca());
            ps.setString(2, a.getColor());

            ps.executeUpdate();
        }
    }

    public List<Auto> listar() throws SQLException {
        List<Auto> lista = new ArrayList();

        String sql = "SELECT * FROM auto";

        try (Connection conn = ConexionDB.getConnection(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Auto a = new Auto();
                a.setMarca(rs.getString("marca"));
                a.setColor(rs.getString("color"));

                lista.add(a);
            }
        }
        return lista;
    }
}

//----------------------------- DB -----------------------------

public class ConexionDB {

    private static final String URL = "jdbc:mysql://localhost:3306/auto?useSSL=false&serverTimezone=America/Santiago";
    private static final String USER = "root";   // XAMPP por defecto
    private static final String PASS = "";       // normalmente vacío

    public static Connection getConnection() throws SQLException {
        try {
            // Driver MySQL 8
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            throw new SQLException("No se encontró el driver de MySQL", ex);
        }
        return DriverManager.getConnection(URL, USER, PASS);
    }

}

//----------------------------- SERVICE -----------------------------

public class AutoService {
    
     private final AutoDAO autodao = new AutoDAO();
    
    public void registarAuto(Auto u) throws Exception {
        if (u.getMarca() == null || u.getMarca().isBlank()) {
            throw new Exception("La marca es obigatoria");
        }
        
        autodao.registro(u);
    }
}

