package cl.duoc.EventixApp.dto.request;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EventoCreateRequest {

    @Positive(message = "El id no puede ser negativo")
    private Integer idEvento;

    @NotBlank(message = "El nombre no puede estar en blanco")
    @NotNull(message = "El nombre no puede ser null")
    private String nombre;

    @FutureOrPresent(message = "El evento no puede ser de una fecha pasada")
    @JsonFormat(pattern = "dd-MM-YYYY")
    private LocalDate fecha;

    @NotBlank(message = "La dirección no puede estar en blanco")
    private String ubicacion;

    @Positive(message = "La capacidad no puede ser negativo")
    private Integer capacidad;
}
