package cl.duoc.EventixApp.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import cl.duoc.EventixApp.model.Evento;

@Repository
public class EventoRepository {

    private final List<Evento> listaEventos = new ArrayList();

    public Evento guardarEvento(Evento evento) {
        listaEventos.add(evento);
        return evento;
    }

    public List<Evento> getAllEventos() {
        return new ArrayList<>(listaEventos);
    }

    public Optional<Evento> obtenerUnEvento(Integer idEvento) {
        for (Evento evento : listaEventos) {
            if (idEvento.equals(evento.getIdEvento())) {
                return Optional.of(evento);
            }
        }
        return Optional.empty();
    }

    public Evento actualizarEvento(Evento actualizar) {
        for (Evento Evento : listaEventos) {
            if (actualizar.getIdEvento().equals(Evento.getIdEvento())) {
                Evento.setNombre(actualizar.getNombre());
                Evento.setFecha(actualizar.getFecha());
                Evento.setUbicacion(actualizar.getUbicacion());
                Evento.setCapacidad(actualizar.getCapacidad());

                return Evento;
            }
        }
        return null;
    }

    public Boolean eliminarEvento(Integer idEvento) {
        for (Evento evento : listaEventos) {
            if (idEvento.equals(evento.getIdEvento())) {
                listaEventos.remove(evento);
                return true;
            }
        }
        return false;
    }
}
