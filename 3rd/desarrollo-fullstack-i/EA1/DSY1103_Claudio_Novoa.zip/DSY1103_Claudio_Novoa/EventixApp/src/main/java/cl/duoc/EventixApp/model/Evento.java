package cl.duoc.EventixApp.model;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Evento {

    private Integer idEvento;
    private String nombre;
    private LocalDate fecha;
    private String ubicacion;
    private Integer capacidad;
}
