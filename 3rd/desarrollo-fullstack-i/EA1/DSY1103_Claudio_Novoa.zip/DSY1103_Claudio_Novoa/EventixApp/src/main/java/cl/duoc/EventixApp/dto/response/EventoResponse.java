package cl.duoc.EventixApp.dto.response;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EventoResponse {

    private Integer idEvento;
    private String nombre;
    private LocalDate fecha;
    private String ubicacion;
    private Integer capacidad;

}
