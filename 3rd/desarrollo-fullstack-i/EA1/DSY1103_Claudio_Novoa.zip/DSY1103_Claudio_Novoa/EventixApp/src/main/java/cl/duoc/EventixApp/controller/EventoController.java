package cl.duoc.EventixApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import cl.duoc.EventixApp.dto.request.EventoCreateRequest;
import cl.duoc.EventixApp.dto.request.EventoUpdateRequest;
import cl.duoc.EventixApp.dto.response.EventoResponse;
import cl.duoc.EventixApp.service.EventoService;
import jakarta.validation.Valid;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PutMapping;

@RestController
@RequestMapping("api/v1/eventos")
public class EventoController {

    @Autowired
    private EventoService eventoService;

    @GetMapping("/evento/{id}")
    public ResponseEntity<EventoResponse> obtenerUnPrducto(@PathVariable Integer id) {
        EventoResponse evento = eventoService.obtenerUnEvento(id);
        if (evento == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(evento);
    }

    @GetMapping("/getAllEventos")
    public ResponseEntity<List<EventoResponse>> getAllEventos() {
        List<EventoResponse> eventos = eventoService.getAllEventos();
        return ResponseEntity.ok(eventos);
    }

    @PostMapping("guardarEvento")
    public ResponseEntity<EventoResponse> guardarEvento(@Valid @RequestBody EventoCreateRequest request) {
        EventoResponse eventoGuardado = eventoService.guardarEvento(request);

        if (eventoGuardado == null) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        } else {
            return ResponseEntity.status(HttpStatus.CREATED).body(eventoGuardado);
        }
    }

    @PutMapping("/actualizarEvento/{id}")
    public ResponseEntity<EventoResponse> actualizarEvento(@PathVariable Integer id,
            @Valid @RequestBody EventoUpdateRequest request) {

        EventoResponse eventoActualizado = eventoService.actualizarEvento(id, request);

        if (eventoActualizado == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(eventoActualizado);
    }

    @DeleteMapping("/eliminarEvento/{id}")
    public ResponseEntity<Void> eliminarEvento(@PathVariable Integer id) {
        boolean eliminado = eventoService.eliminarEvento(id);

        if (!eliminado) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.noContent().build();
    }
}
