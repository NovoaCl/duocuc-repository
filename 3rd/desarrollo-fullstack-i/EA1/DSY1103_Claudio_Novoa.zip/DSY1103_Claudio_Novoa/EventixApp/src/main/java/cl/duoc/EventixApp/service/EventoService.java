package cl.duoc.EventixApp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duoc.EventixApp.dto.request.EventoCreateRequest;
import cl.duoc.EventixApp.dto.request.EventoUpdateRequest;
import cl.duoc.EventixApp.dto.response.EventoResponse;
import cl.duoc.EventixApp.model.Evento;
import cl.duoc.EventixApp.repository.EventoRepository;

@Service
public class EventoService {

    @Autowired
    private EventoRepository eventoRepository;

    public EventoResponse guardarEvento(EventoCreateRequest request) {
        Evento evento = new Evento();

        evento.setIdEvento(request.getIdEvento());
        evento.setNombre(request.getNombre());
        evento.setFecha(request.getFecha());
        evento.setUbicacion(request.getUbicacion());
        evento.setCapacidad(request.getCapacidad());

        Optional<Evento> buscarEvento = eventoRepository.obtenerUnEvento(evento.getIdEvento());

        if (buscarEvento.isPresent()) {
            return null;
        }

        Evento eventoGuardado = eventoRepository.guardarEvento(evento);
        return new EventoResponse(
                evento.getIdEvento(),
                eventoGuardado.getNombre(),
                eventoGuardado.getFecha(),
                eventoGuardado.getUbicacion(),
                eventoGuardado.getCapacidad());

    }

    public List<EventoResponse> getAllEventos() {
        List<Evento> eventos = eventoRepository.getAllEventos();
        List<EventoResponse> respuesta = new ArrayList<>();

        for (Evento evento : eventos) {
            EventoResponse response = new EventoResponse(
                    evento.getIdEvento(),
                    evento.getNombre(),
                    evento.getFecha(),
                    evento.getUbicacion(),
                    evento.getCapacidad());
            respuesta.add(response);
        }

        return respuesta;
    }

    public EventoResponse obtenerUnEvento(Integer idEvento) {
        Evento evento = eventoRepository.obtenerUnEvento(idEvento).orElse(null);

        if (evento == null) {
            return null;
        }

        return new EventoResponse(
                evento.getIdEvento(),
                evento.getNombre(),
                evento.getFecha(),
                evento.getUbicacion(),
                evento.getCapacidad());
    }

    public EventoResponse actualizarEvento(Integer idEvento, EventoUpdateRequest request) {
        Evento evento = new Evento();

        evento.setNombre(request.getNombre());
        evento.setFecha(request.getFecha());
        evento.setUbicacion(request.getUbicacion());
        evento.setCapacidad(request.getCapacidad());

        Evento eventoActualizado = eventoRepository.actualizarEvento(evento);

        if (eventoActualizado == null) {
            return null;
        }

        return new EventoResponse(
                evento.getIdEvento(),
                eventoActualizado.getNombre(),
                eventoActualizado.getFecha(),
                eventoActualizado.getUbicacion(),
                eventoActualizado.getCapacidad());
    }

    public boolean eliminarEvento(Integer idEvento) {
        return eventoRepository.eliminarEvento(idEvento);
    }
}
