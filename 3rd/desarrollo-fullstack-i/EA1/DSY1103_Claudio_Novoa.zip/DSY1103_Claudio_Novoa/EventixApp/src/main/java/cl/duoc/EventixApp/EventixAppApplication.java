package cl.duoc.EventixApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventixAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventixAppApplication.class, args);
	}

}
