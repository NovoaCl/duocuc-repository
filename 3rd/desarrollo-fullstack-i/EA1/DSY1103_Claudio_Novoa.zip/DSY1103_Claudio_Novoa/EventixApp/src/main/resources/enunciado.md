CONTEXTO DEL PROBLEMA
Una organización llamada Eventix se encuentra desarrollando una plataforma digital
orientada a la gestión de eventos y actividades organizadas por distintas entidades.
Debido al crecimiento de la plataforma y la necesidad de soportar múltiples tipos de
eventos, la organización ha decidido migrar su sistema hacia una arquitectura basada en
microservicios, con el objetivo de mejorar la flexibilidad, escalabilidad y mantenibilidad del
sistema.
En esta primera etapa, el equipo de desarrollo deberá implementar un microservicio
encargado de gestionar los eventos registrados en la plataforma.
Este microservicio será responsable de registrar, administrar y consultar la información
asociada a los eventos disponibles para los usuarios.
Dado que el sistema se encuentra en fase inicial de desarrollo, la información deberá
almacenarse en memoria, utilizando estructuras de datos apropiadas.
OBJETIVO PRINCIPAL
Desarrollar un microservicio backend utilizando Java Spring Boot, que permita gestionar
los eventos del sistema mediante una API REST.
El microservicio deberá implementar operaciones que permitan:
• Registrar nuevos eventos
• Consultar eventos existentes
• Actualizar información de eventos
• Eliminar eventos del sistema
• Realizar consultas específicas sobre los eventos registrados
El diseño e implementación deberán realizarse aplicando buenas prácticas de desarrollo
de microservicios.
REQUERIMIENTOS GENERALES
El microservicio deberá permitir administrar un conjunto de eventos dentro del sistema.
Cada evento representará una actividad organizada dentro de la plataforma.
Usted deberá definir el modelo de datos adecuado para representar un evento dentro del
sistema, considerando atributos relevantes para su gestión.
Entre los aspectos que pueden considerarse se encuentran, por ejemplo:

• Nombre o descripción
• Tipo de evento
• Fecha de realización
• Ubicación
• Capacidad o cantidad de participantes
Usted deberá analizar qué atributos son necesarios y seleccionar los tipos de datos
apropiados.
MODELADO DEL DOMINIO
El sistema deberá representar los eventos mediante clases que describan su información y
comportamiento.
Debe diseñar el modelo de dominio considerando:
• Atributos relevantes para el contexto del problema
• Tipos de datos adecuados
• Identificadores únicos
• Estructuras que permitan gestionar múltiples incidencias
El sistema deberá utilizar colecciones en memoria para almacenar la información.
OPERACIONES DEL MICROSERVICIO
El microservicio deberá permitir realizar operaciones básicas de administración sobre los
eventos del sistema.
Entre las funcionalidades mínimas que el servicio debe permitir se encuentran:
• Registrar nuevos eventos
• Consultar los eventos almacenados
• Buscar eventos según algún criterio relevante
• Modificar información de eventos existentes
• Eliminar eventos del sistema
Además, el sistema deberá permitir realizar al menos una operación de procesamiento o
transformación sobre la colección de eventos, como, por ejemplo:
• Ordenar eventos
• Buscar información específica
• Generar subconjuntos de datos
Debe definir e implementar una operación de manera coherente con el dominio del
problema.
DISEÑO DE LA API
El microservicio deberá exponer sus funcionalidades mediante endpoints REST, utilizando
métodos HTTP adecuados para cada operación.
El sistema deberá estar diseñado mediante:
• Rutas REST semánticamente correctas
• Uso adecuado de métodos HTTP
• Parámetros de ruta cuando corresponda
• Estructuras de respuesta en formato JSON
Las respuestas del servicio deberán incluir códigos HTTP apropiados según el resultado de
cada operación.
VALIDACIÓN DE DATOS
El sistema deberá implementar mecanismos de validación que permitan asegurar la
integridad de los datos recibidos por el microservicio.
El sistema deberá aplicar validaciones que impidan el registro de información inválida
dentro del sistema.
En caso de error en los datos de entrada, el microservicio deberá retornar mensajes claros
que permitan identificar el problema.
MANEJO DE ERRORES
El microservicio deberá ser capaz de manejar situaciones de error de manera controlada.
Entre los posibles escenarios de error se encuentran:
• Solicitudes sobre recursos inexistentes
• Datos inválidos
• Operaciones que no puedan completarse
El sistema deberá manejar estas situaciones sin provocar fallos en la ejecución del
servicio.
ESTRUCTURA TÉCNICA REQUERIDA
El proyecto deberá organizarse aplicando el patrón de arquitectura:
Controller – Service – Repository/Model (CSR)
Cada capa deberá mantener responsabilidades claramente definidas.
PRUEBAS DEL SERVICIO
Se deberá verificar el correcto funcionamiento del microservicio mediante pruebas de
comunicación REST utilizando herramientas como Postman o similares.
Las pruebas deberán permitir validar:
• La correcta ejecución de los endpoints
• El formato de las respuestas
• Los códigos HTTP retornados
• El manejo adecuado de errores
ENTREGA
El proyecto desarrollado deberá ser:
• Comprimido
• Subido a la plataforma AVA
antes de finalizar la sesión.
El archivo deberá contener el proyecto completo desarrollado durante la evaluación.