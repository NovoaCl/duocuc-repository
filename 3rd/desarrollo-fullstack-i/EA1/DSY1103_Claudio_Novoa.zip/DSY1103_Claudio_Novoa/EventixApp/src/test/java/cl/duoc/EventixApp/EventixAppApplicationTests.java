package cl.duoc.EventixApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventixAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
