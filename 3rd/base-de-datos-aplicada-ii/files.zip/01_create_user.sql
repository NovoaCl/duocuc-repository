-- ================================================
-- SCRIPT PARA MDY2131_P1
-- PRÁCTICA: P1
-- Este script se ejecuta automáticamente la primera
-- vez que el contenedor crea la base de datos.
-- ================================================

-- 1. Cambiar al PDB (XEPDB1)
ALTER SESSION SET CONTAINER = XEPDB1;

-- 2. Crear usuario local
CREATE USER MDY2131_P1 IDENTIFIED BY "MDY2131.practica_p1"
  DEFAULT TABLESPACE "USERS"
  TEMPORARY TABLESPACE "TEMP";

-- 3. Asignar cuota
ALTER USER MDY2131_P1 QUOTA UNLIMITED ON USERS;

-- 4. Otorgar permisos básicos
GRANT CREATE SESSION TO MDY2131_P1;
GRANT "RESOURCE" TO MDY2131_P1;
ALTER USER MDY2131_P1 DEFAULT ROLE "RESOURCE";

-- 5. Verificar creación (opcional)
SELECT username, account_status, default_tablespace
FROM dba_users
WHERE username = 'MDY2131_P1';
